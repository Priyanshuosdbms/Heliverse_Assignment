// src/agents/rdlAgent.js
// Pipeline: Master JSON → TOML (via @iarna/toml) → SystemRDL 2.0 (via LangChain agent loop)
// The agent validates RDL output and self-corrects via Observe → Reason → Act iterations.

import { ChatAnthropic } from '@langchain/anthropic';
import { tool } from '@langchain/core/tools';
import { createReactAgent } from '@langchain/langgraph/prebuilt';
import { HumanMessage } from '@langchain/core/messages';
import TOML from '@iarna/toml';
import { z } from 'zod';
import fs from 'fs';
import path from 'path';
import { Logger } from '../utils/logger.js';

const log = new Logger('RDL-AGENT');

// ─── JSON → TOML ───────────────────────────────────────────────────────────

/**
 * Convert master JSON register map to TOML intermediate format.
 * TOML is used as a clean intermediate before handing to RDL generation
 * (mirrors the "official node/npm" toml conversion step).
 */
export function jsonToToml(masterJSON) {
  log.act('Converting master JSON → TOML intermediate');

  // @iarna/toml requires plain objects — map register data cleanly
  const tomlData = {
    schema_version: masterJSON.schema_version,
    metadata: {
      generated_at: masterJSON.metadata.generated_at,
      source_files: masterJSON.metadata.source_files,
      total_registers: masterJSON.metadata.total_registers,
    },
    register: masterJSON.registers.map(r => ({
      name:        r.name,
      address:     r.address,
      description: r.description,
      access:      r.access,
      reset:       r.reset,
      width:       r.width || 32,
      field: (r.fields || []).map(f => ({
        name:        f.name,
        bits:        f.bits,
        access:      f.access,
        reset:       f.reset,
        description: f.description,
      })),
    })),
  };

  const tomlString = TOML.stringify(tomlData);
  log.observe(`TOML generated: ${tomlString.length.toLocaleString()} chars, ${masterJSON.registers.length} registers`);
  return tomlString;
}

// ─── RDL validation tool ────────────────────────────────────────────────────

const validateRdlTool = tool(
  async ({ rdl_code, issues }) => {
    log.act(`Tool called: validate_rdl — ${issues.length} issue(s) reported`);
    // In a real setup this would run `peakrdl check` or `systemrdl` CLI
    // For now we return the issues so the agent can reason about fixing them
    return JSON.stringify({
      issues_found: issues.length,
      issues,
      status: issues.length === 0 ? 'valid' : 'needs_fixes',
    });
  },
  {
    name: 'validate_rdl',
    description: 'Validate SystemRDL syntax. Report any issues you found in the RDL code you generated.',
    schema: z.object({
      rdl_code: z.string().describe('The full SystemRDL code to validate'),
      issues:   z.array(z.string()).describe('List of issues found (empty array if code is valid)'),
    }),
  }
);

const submitRdlTool = tool(
  async ({ rdl_code, description }) => {
    log.observe(`Tool called: submit_rdl — "${description}"`);
    return JSON.stringify({ accepted: true, rdl_code });
  },
  {
    name: 'submit_rdl',
    description: 'Submit the final validated SystemRDL code. Call this only when the RDL is correct and complete.',
    schema: z.object({
      rdl_code:    z.string().describe('Final, validated SystemRDL 2.0 code'),
      description: z.string().describe('Brief description of what was generated'),
    }),
  }
);

// ─── RDL Agent ─────────────────────────────────────────────────────────────

function buildRdlAgent(systemPromptText) {
  const llm = new ChatAnthropic({
    model: 'claude-opus-4-5',
    temperature: 0,
    maxTokens: 8192,
  });

  return createReactAgent({
    llm,
    tools: [validateRdlTool, submitRdlTool],
    messageModifier: systemPromptText,
  });
}

/**
 * Load system prompt from file or use default.
 */
function loadSystemPrompt(customPath) {
  const defaultPath = path.resolve('config/rdl_system_prompt.md');
  const target = customPath || process.env.RDL_SYSTEM_PROMPT_FILE || defaultPath;

  if (fs.existsSync(target)) {
    log.perceive(`Loading RDL system prompt from: ${target}`);
    return fs.readFileSync(target, 'utf8');
  }

  log.warn('RDL system prompt file not found — using built-in default');
  return `You are a SystemRDL 2.0 expert. Convert the given register map data into valid SystemRDL 2.0 code.
Use addrmap, reg, and field constructs. Include all access types, reset values, and descriptions.
Validate your output by calling validate_rdl, fix any issues, then call submit_rdl with the final code.
Output only valid SystemRDL 2.0 — no markdown, no prose.`;
}

// ─── Main export ───────────────────────────────────────────────────────────

/**
 * Run the full JSON → TOML → RDL pipeline.
 * Returns { toml: string, rdl: string }
 */
export async function runRdlPipeline(masterJSON, rdlSystemPromptPath, maxIterations = 10) {
  log.divider?.('Stage 3 — JSON → TOML → RDL');

  // Step 1: JSON → TOML
  const toml = jsonToToml(masterJSON);

  // Step 2: TOML → RDL via agent loop
  const systemPrompt = loadSystemPrompt(rdlSystemPromptPath);
  const agent = buildRdlAgent(systemPrompt);

  const userMessage = `
Convert the following register map (provided as TOML for clarity) into SystemRDL 2.0.

${toml}

Steps:
1. Generate the SystemRDL 2.0 code
2. Call validate_rdl to check for any issues
3. If there are issues, fix them and validate again
4. Once valid, call submit_rdl with the final code
  `.trim();

  log.reason('Agent loop: generating SystemRDL from TOML...');

  const result = await agent.invoke(
    { messages: [new HumanMessage(userMessage)] },
    { recursionLimit: maxIterations }
  );

  // Extract the submitted RDL from tool messages
  let rdl = null;
  for (const msg of result.messages) {
    if (msg.constructor.name === 'ToolMessage' && msg.name === 'submit_rdl') {
      try {
        const parsed = JSON.parse(msg.content);
        if (parsed.accepted && parsed.rdl_code) {
          rdl = parsed.rdl_code;
        }
      } catch { /* ignore */ }
    }
  }

  // Fallback: pull RDL from the last AI text message if submit_rdl wasn't called
  if (!rdl) {
    log.warn('submit_rdl tool was not called — extracting RDL from last AI message');
    for (let i = result.messages.length - 1; i >= 0; i--) {
      const msg = result.messages[i];
      if (msg.constructor.name === 'AIMessage' && msg.content) {
        // Strip markdown fences if present
        rdl = msg.content.replace(/```[a-z]*\n?/g, '').replace(/```/g, '').trim();
        break;
      }
    }
  }

  if (!rdl) {
    throw new Error('RDL agent did not produce any output');
  }

  log.success(`RDL generated: ${rdl.length.toLocaleString()} chars`);
  return { toml, rdl };
}
