# Register Agent Pipeline

A **LangChain deep agent** pipeline that converts hardware register documents into Renode C# peripheral code, following the [AI Agent Loop](https://blogs.oracle.com/developers/what-is-the-ai-agent-loop-the-core-architecture-behind-autonomous-ai-systems) pattern (Perceive → Reason → Plan → Act → Observe).

```
Documents (PDF / DOCX / XLSX / XLSM)
        │
        ▼  Stage 1 — Document Parser
   Parsed Text (with page/sheet hints)
        │
        ▼  Stage 2 — LangChain Parse Agent Loop
   master.json  (register map)
        │
        ▼  Stage 3 — RDL Agent Loop
   registers.toml  →  registers.rdl  (SystemRDL 2.0)
        │
        ▼  Stage 4 — PeakRDL-renode + Self-healing Agent Loop
   RegisterPeripheral.cs  +  README.md  (fix log)
```

---

## Prerequisites

### Node.js dependencies
```bash
npm install
```

### Python — PeakRDL-renode
```bash
pip install peakrdl-renode
# Verify:
peakrdl --version
```

### Environment
```bash
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
```

---

## Usage

### Basic — single PDF with page range
```bash
node src/index.js \
  --file ./docs/datasheet.pdf \
  --pages 134:450 \
  --output ./output
```

### Multiple files — PDF + Excel + DOCX
```bash
node src/index.js \
  --file ./docs/register_map.pdf  --pages 10:80 \
  --file ./docs/fields.xlsx       --sheets "Registers,Bitfields" \
  --file ./docs/notes.docx        --pages 1:20 \
  --output ./output
```

### Custom RDL system prompt
```bash
node src/index.js \
  --file ./docs/datasheet.pdf \
  --pages 134:450 \
  --rdl-prompt ./config/rdl_system_prompt.md \
  --output ./output
```

### Demo mode (no files needed)
```bash
node src/index.js --demo --output ./output
```

---

## File hints

| File type     | Hint flag      | Example                          |
|---------------|----------------|----------------------------------|
| PDF           | `--pages from:to` | `--pages 134:450`             |
| DOC / DOCX    | `--pages from:to` | `--pages 1:50` *(approximated)* |
| XLSX / XLSM   | `--sheets "..."` | `--sheets "Registers,Bitfields"` |

Hints are matched **positionally** — the first `--pages` applies to the first `--file`, the second to the second, and so on.

---

## Output files

| File | Description |
|------|-------------|
| `master.json` | Parsed register map (all registers + fields) |
| `registers.toml` | TOML intermediate (via `@iarna/toml`) |
| `registers.rdl` | SystemRDL 2.0 source |
| `registers_final.rdl` | Patched RDL (if fixes were applied) |
| `RegisterPeripheral.cs` | Renode C# peripheral code |
| `README.md` | Fix log — every auto-correction documented |

---

## Agent Loop Architecture

Each stage runs a LangChain `createReactAgent` loop:

```
while not done:
    response = llm(messages)
    if response has tool_calls:
        results = execute_tools(response.tool_calls)
        messages.append(results)
    else:
        done = True
```

### Stage 2 — Parse Agent tools
| Tool | Purpose |
|------|---------|
| `extract_registers` | Agent calls this with structured register data per section |
| `mark_section_done` | Agent marks a document section as fully processed |

### Stage 3 — RDL Agent tools
| Tool | Purpose |
|------|---------|
| `validate_rdl` | Agent self-reports any RDL syntax issues |
| `submit_rdl` | Agent submits the final validated RDL |

### Stage 4 — C# Self-healing tools
| Tool | Purpose |
|------|---------|
| `patch_rdl` | Agent fixes RDL errors and documents the change |
| `generate_csharp_fallback` | Last-resort: generate C# directly if PeakRDL is unfixable |

### Stopping conditions (per Oracle Agent Loop guidance)
- `recursionLimit` caps the agent at `--max-iterations` LLM calls per stage
- Each stage exits cleanly on success without further iterations
- PeakRDL retry limited to 3 attempts before fallback triggers

---

## Custom RDL System Prompt

Edit `config/rdl_system_prompt.md` to customize how the RDL agent generates SystemRDL. The file is loaded at runtime — no rebuild needed.

---

## Project structure

```
register-agent/
├── src/
│   ├── index.js                  # CLI entry point
│   ├── pipeline/
│   │   └── orchestrator.js       # 4-stage pipeline coordinator
│   ├── agents/
│   │   ├── parseAgent.js         # Stage 2: document → JSON agent loop
│   │   ├── rdlAgent.js           # Stage 3: JSON → TOML → RDL agent loop
│   │   └── csharpAgent.js        # Stage 4: RDL → C# + self-healing loop
│   ├── tools/
│   │   └── documentParser.js     # PDF / DOCX / XLSX / XLSM extractors
│   └── utils/
│       └── logger.js             # Structured agent-loop logger
├── config/
│   └── rdl_system_prompt.md      # SystemRDL generation prompt (editable)
├── output/                       # Generated files land here
├── .env.example
└── package.json
```

---

## Troubleshooting

**`peakrdl: command not found`**
Install PeakRDL-renode: `pip install peakrdl-renode`

**PDF page range not working**
Some PDFs don't use form-feed (`\x0C`) as page separators. The full text is still extracted — the page filter is best-effort.

**DOCX page range is approximate**
Word documents don't encode exact page breaks in raw text. The agent uses a ~4-paragraphs-per-page heuristic.

**Agent loop hits iteration limit**
Increase `--max-iterations` (default: 10). Complex register maps with many fields may need more iterations.

**`ANTHROPIC_API_KEY` not set**
Copy `.env.example` to `.env` and add your key from https://console.anthropic.com
