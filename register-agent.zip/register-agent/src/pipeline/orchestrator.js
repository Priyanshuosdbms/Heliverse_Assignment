// src/pipeline/orchestrator.js
// Orchestrates the full 4-stage pipeline following the AI Agent Loop pattern:
// Perceive → Reason → Plan → Act → Observe (repeat until done)
//
// Reference: Oracle AI Agent Loop article — LLM + tools in a while loop,
// with stopping conditions, cost awareness, and structured observability.

import fs from 'fs-extra';
import path from 'path';
import { parseAllDocuments } from '../tools/documentParser.js';
import { runParseAgent } from '../agents/parseAgent.js';
import { runRdlPipeline } from '../agents/rdlAgent.js';
import { runCsharpPipeline } from '../agents/csharpAgent.js';
import { Logger } from '../utils/logger.js';

const log = new Logger('PIPELINE');

/**
 * @typedef {Object} PipelineConfig
 * @property {Array<import('../tools/documentParser.js').FileHint>} files
 * @property {string} [outputDir]              - default: ./output
 * @property {string} [rdlSystemPromptFile]    - path to .md system prompt
 * @property {number} [maxIterations]          - agent loop limit (default: 10)
 */

/**
 * Run the full register processing pipeline.
 *
 * Stage 1: Parse documents (PDF/DOCX/XLSX) with hints
 * Stage 2: Agent loop → master JSON
 * Stage 3: JSON → TOML → RDL (agent loop with validation)
 * Stage 4: RDL → C# via PeakRDL-renode (self-healing agent loop + README)
 */
export async function runPipeline(config) {
  const {
    files,
    outputDir        = process.env.OUTPUT_DIR || './output',
    rdlSystemPromptFile,
    maxIterations    = parseInt(process.env.MAX_ITERATIONS) || 10,
  } = config;

  await fs.ensureDir(outputDir);

  const startTime = Date.now();
  log.divider('Register Agent Pipeline — Starting');
  log.info(`Output directory: ${path.resolve(outputDir)}`);
  log.info(`Max agent iterations: ${maxIterations}`);
  log.info(`Files to process: ${files.length}`);

  // ── STAGE 1: Document parsing ────────────────────────────────────────────
  log.divider('Stage 1 — Document Parsing');
  log.perceive(`Reading ${files.length} document file(s)...`);

  const parsedDocs = await parseAllDocuments(files);
  log.success(`Stage 1 complete: ${parsedDocs.length} document(s) parsed`);

  // ── STAGE 2: Parse agent loop → master JSON ──────────────────────────────
  const masterJSON = await runParseAgent(parsedDocs, maxIterations);

  if (!masterJSON.registers || masterJSON.registers.length === 0) {
    log.warn('No registers extracted — check your documents and page/sheet hints');
  }

  const jsonPath = path.join(outputDir, 'master.json');
  await fs.writeJSON(jsonPath, masterJSON, { spaces: 2 });
  log.success(`Stage 2 complete: master.json → ${jsonPath}`);

  // ── STAGE 3: JSON → TOML → RDL ──────────────────────────────────────────
  const { toml, rdl } = await runRdlPipeline(masterJSON, rdlSystemPromptFile, maxIterations);

  const tomlPath = path.join(outputDir, 'registers.toml');
  const rdlPath  = path.join(outputDir, 'registers.rdl');
  await fs.writeFile(tomlPath, toml, 'utf8');
  await fs.writeFile(rdlPath,  rdl,  'utf8');
  log.success(`Stage 3 complete: registers.toml + registers.rdl → ${outputDir}`);

  // ── STAGE 4: RDL → C# via PeakRDL-renode ───────────────────────────────
  const { csharp, readme, patchedRdl, csPath } = await runCsharpPipeline(
    rdl,
    outputDir,
    maxIterations
  );

  // Write README
  const readmePath = path.join(outputDir, 'README.md');
  await fs.writeFile(readmePath, readme, 'utf8');

  // ── Final summary ────────────────────────────────────────────────────────
  const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
  log.divider('Pipeline Complete');
  log.success(`Total time: ${elapsed}s`);
  log.info(`\nOutput files:`);
  log.info(`  📄 ${path.resolve(jsonPath)}    (master register JSON)`);
  log.info(`  📄 ${path.resolve(tomlPath)}   (TOML intermediate)`);
  log.info(`  📄 ${path.resolve(rdlPath)}    (SystemRDL 2.0)`);
  log.info(`  📄 ${path.resolve(csPath)}     (Renode C# peripheral)`);
  log.info(`  📄 ${path.resolve(readmePath)} (fix log & README)`);

  return { masterJSON, toml, rdl, csharp, readme };
}
