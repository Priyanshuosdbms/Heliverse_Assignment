// src/agents/parseAgent.js
// LangGraph deep agent: Perceive → Reason → Plan → Act → Observe loop
// Converts parsed document text into a structured master JSON register map.

import { ChatOpenAI } from '@langchain/openai';
import { tool } from '@langchain/core/tools';
import { createReactAgent } from '@langchain/langgraph/prebuilt';
import { HumanMessage } from '@langchain/core/messages';
import { z } from 'zod';
import { Logger } from '../utils/logger.js';

const log = new Logger('PARSE-AGENT');

// ─── Tool definitions ──────────────────────────────────────────────────────

/**
 * Tool: extract_registers
 * The LLM calls this tool with structured register data it found in a chunk.
 * The agent loop iterates over chunks and accumulates results.
 */
const extractRegistersTool = tool(
  async ({ registers }) => {
    log.act(`Tool called: extract_registers — found ${registers.length} register(s)`);
    return JSON.stringify({ extracted: registers.length, registers });
  },
  {
    name: 'extract_registers',
    description:
      'Extract register definitions found in the document text. Call this once per logical group of registers you identify.',
    schema: z.object({
      registers: z.array(
        z.object({
          name:        z.string().describe('Register name, e.g. CTRL, STATUS'),
          address:     z.string().describe('Hex address offset, e.g. 0x00'),
          description: z.string().describe('Human-readable description'),
          access:      z.enum(['RO', 'WO', 'RW', 'W1C', 'RC']).describe('Register-level access type'),
          reset:       z.string().describe('Reset/default value in hex, e.g. 0x00000000'),
          width:       z.number().optional().describe('Register width in bits (default 32)'),
          fields: z.array(
            z.object({
              name:        z.string(),
              bits:        z.string().describe('Bit range e.g. 0 or 3:1'),
              access:      z.enum(['RO', 'WO', 'RW', 'W1C', 'RC']),
              reset:       z.string().describe('Reset value for this field'),
              description: z.string(),
            })
          ).describe('Bit fields within the register'),
        })
      ).describe('Array of registers extracted from this section of the document'),
    }),
  }
);

/**
 * Tool: mark_section_done
 * Agent calls this when it has finished processing a chunk.
 */
const markSectionDoneTool = tool(
  async ({ section, reason }) => {
    log.observe(`Section complete: "${section}" — ${reason}`);
    return `Section "${section}" marked as processed.`;
  },
  {
    name: 'mark_section_done',
    description: 'Mark a document section as fully processed. Call this after extracting all registers from a section.',
    schema: z.object({
      section: z.string().describe('Section name or page range'),
      reason:  z.string().describe('Brief reason why section is complete'),
    }),
  }
);

// ─── Agent factory ─────────────────────────────────────────────────────────

function buildParseAgent() {
  const llm = new ChatOpenAI({
    model: process.env.VLLM_MODEL || 'Qwen/Qwen3-6B',
    temperature: 0,
    maxTokens: 4096,
    configuration: {
      baseURL: process.env.VLLM_BASE_URL || 'http://localhost:8000/v1',
      apiKey: process.env.VLLM_API_KEY || 'EMPTY',
    },
  });

  const systemPrompt = `You are a hardware register map extraction agent operating in an iterative agent loop.

Your task: Read the provided document text (which may be a mix of PDF, DOCX, and spreadsheet content) and extract EVERY register definition you find.

## What to look for
- Register names (often ALL_CAPS, e.g. CTRL, STATUS, DATA, IRQ_EN)
- Address offsets (hex values like 0x00, 0x04, or decimal)
- Access types: RO (read-only), RW (read-write), WO (write-only), W1C (write-1-to-clear), RC (read-to-clear)
- Bit field definitions: field name, bit position/range, access, reset value, description
- Reset/default values
- Register descriptions

## How to operate
1. PERCEIVE: Read the document text carefully
2. REASON: Identify all register-related content
3. PLAN: Group registers logically (by section, by address range)
4. ACT: Call extract_registers for each group you find
5. OBSERVE: After calling extract_registers, check if there are more registers to find
6. Repeat until all registers are extracted
7. Call mark_section_done when a section is fully processed

## Important
- Extract ALL registers you can find — do not skip any
- If a table row looks like a register or field, extract it
- Infer missing fields from context where possible
- If bit width is not stated, assume 32-bit registers`;

  return createReactAgent({
    llm,
    tools: [extractRegistersTool, markSectionDoneTool],
    messageModifier: systemPrompt,
  });
}

// ─── Main export ───────────────────────────────────────────────────────────

/**
 * Run the parse agent loop over all parsed document text.
 * Returns a master JSON register map.
 *
 * @param {Array<{fileName: string, type: string, content: string}>} parsedDocs
 * @param {number} maxIterations
 * @returns {Promise<Object>} masterJSON
 */
export async function runParseAgent(parsedDocs, maxIterations = 10) {
  log.divider?.('Stage 2 — Parse Agent Loop');
  log.perceive(`Starting agent loop over ${parsedDocs.length} document(s)`);

  const agent = buildParseAgent();
  const allRegisters = [];

  // Process each document — the agent loops internally per document
  for (const doc of parsedDocs) {
    log.plan(`Processing document: ${doc.fileName} (${doc.type})`);

    // Chunk large documents to stay within context window
    const chunks = chunkText(doc.content, 12000);
    log.reason(`Split into ${chunks.length} chunk(s) for agent processing`);

    for (let ci = 0; ci < chunks.length; ci++) {
      const chunk = chunks[ci];
      const userMessage = `
Document: ${doc.fileName} (${doc.type})
Chunk: ${ci + 1} of ${chunks.length}

--- BEGIN DOCUMENT TEXT ---
${chunk}
--- END DOCUMENT TEXT ---

Extract all hardware registers from this text. Call extract_registers for each group of registers you find. Call mark_section_done when finished with this chunk.
      `.trim();

      log.reason(`Agent loop: chunk ${ci + 1}/${chunks.length} of ${doc.fileName}`);

      try {
        const result = await agent.invoke(
          { messages: [new HumanMessage(userMessage)] },
          { recursionLimit: maxIterations }
        );

        // Collect all tool call results from the agent's message history
        for (const msg of result.messages) {
          if (msg.constructor.name === 'ToolMessage' && msg.name === 'extract_registers') {
            try {
              const parsed = JSON.parse(msg.content);
              if (parsed.registers) {
                allRegisters.push(...parsed.registers);
                log.observe(`Accumulated ${parsed.registers.length} register(s) from chunk ${ci + 1}`);
              }
            } catch {
              // tool result may already be accumulated — ignore parse errors on non-JSON tool msgs
            }
          }
        }
      } catch (err) {
        log.error(`Agent error on chunk ${ci + 1}: ${err.message}`);
        throw err;
      }
    }
  }

  // Deduplicate by name+address
  const seen = new Set();
  const deduped = allRegisters.filter(r => {
    const key = `${r.name}::${r.address}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  if (deduped.length < allRegisters.length) {
    log.warn(`Deduplicated ${allRegisters.length - deduped.length} duplicate register(s)`);
  }

  // Sort by address
  deduped.sort((a, b) => {
    const ai = parseInt(a.address, 16) || 0;
    const bi = parseInt(b.address, 16) || 0;
    return ai - bi;
  });

  const masterJSON = {
    schema_version: '1.0',
    metadata: {
      generated_at: new Date().toISOString(),
      source_files: parsedDocs.map(d => d.fileName),
      total_registers: deduped.length,
    },
    registers: deduped,
  };

  log.success(`Master JSON complete: ${deduped.length} unique register(s) across ${parsedDocs.length} file(s)`);
  return masterJSON;
}

// ─── Helpers ───────────────────────────────────────────────────────────────

function chunkText(text, maxChars) {
  if (text.length <= maxChars) return [text];
  const chunks = [];
  let i = 0;
  while (i < text.length) {
    // Try to split on a newline boundary near maxChars
    let end = Math.min(i + maxChars, text.length);
    if (end < text.length) {
      const nl = text.lastIndexOf('\n', end);
      if (nl > i) end = nl;
    }
    chunks.push(text.slice(i, end));
    i = end;
  }
  return chunks;
}
