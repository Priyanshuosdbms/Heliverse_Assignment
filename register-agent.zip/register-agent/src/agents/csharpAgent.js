// src/agents/csharpAgent.js
// Runs PeakRDL-renode to generate C# from RDL.
// If PeakRDL errors occur, a LangChain agent loop diagnoses and patches the RDL,
// then retries. All fixes are accumulated into a README changelog.

import { ChatOpenAI } from '@langchain/openai';
import { tool } from '@langchain/core/tools';
import { createReactAgent } from '@langchain/langgraph/prebuilt';
import { HumanMessage } from '@langchain/core/messages';
import { z } from 'zod';
import { execSync, spawnSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { Logger } from '../utils/logger.js';

const log = new Logger('CSHARP-AGENT');

// ─── PeakRDL runner ────────────────────────────────────────────────────────

/**
 * Run PeakRDL-renode on an RDL file. Returns { success, output, error }.
 */
function runPeakRdl(rdlFilePath, outputDir) {
  log.act(`Running: peakrdl renode "${rdlFilePath}" -o "${outputDir}"`);

  const result = spawnSync(
    'peakrdl',
    ['renode', rdlFilePath, '-o', outputDir],
    { encoding: 'utf8', timeout: 60_000 }
  );

  if (result.error) {
    // peakrdl not installed or not in PATH
    return {
      success: false,
      output: '',
      error: `peakrdl command failed: ${result.error.message}. Ensure PeakRDL-renode is installed: pip install peakrdl-renode`,
    };
  }

  if (result.status !== 0) {
    return {
      success: false,
      output: result.stdout || '',
      error: (result.stderr || '') + (result.stdout || ''),
    };
  }

  // Collect generated C# files
  const csFiles = fs.readdirSync(outputDir)
    .filter(f => f.endsWith('.cs'))
    .map(f => fs.readFileSync(path.join(outputDir, f), 'utf8'))
    .join('\n\n');

  return { success: true, output: csFiles, error: '' };
}

// ─── Fix tools for the self-healing agent ──────────────────────────────────

const patchRdlTool = tool(
  async ({ original_rdl, patched_rdl, fix_description }) => {
    log.act(`Tool called: patch_rdl — "${fix_description}"`);
    return JSON.stringify({ patched: true, rdl: patched_rdl, fix: fix_description });
  },
  {
    name: 'patch_rdl',
    description: 'Apply a fix to the RDL source to resolve a PeakRDL compilation error.',
    schema: z.object({
      original_rdl:    z.string().describe('The original RDL that had errors'),
      patched_rdl:     z.string().describe('The fixed RDL code'),
      fix_description: z.string().describe('Human-readable description of what was changed and why'),
    }),
  }
);

const generateCsharpFallbackTool = tool(
  async ({ csharp_code, notes }) => {
    log.act(`Tool called: generate_csharp_fallback — "${notes}"`);
    return JSON.stringify({ generated: true, csharp: csharp_code, notes });
  },
  {
    name: 'generate_csharp_fallback',
    description:
      'If PeakRDL cannot be fixed, generate equivalent Renode C# peripheral code directly from the register map. Use as last resort.',
    schema: z.object({
      csharp_code: z.string().describe('Valid Renode C# peripheral code'),
      notes:       z.string().describe('Explanation of what was generated and any assumptions made'),
    }),
  }
);

// ─── Self-healing agent ────────────────────────────────────────────────────

function buildCsharpAgent() {
  const llm = new ChatOpenAI({
    model: process.env.VLLM_MODEL || 'Qwen/Qwen3-6B',
    temperature: 0,
    maxTokens: 8192,
    configuration: {
      baseURL: process.env.VLLM_BASE_URL || 'http://localhost:8000/v1',
      apiKey: process.env.VLLM_API_KEY || 'EMPTY',
    },
  });

  const systemPrompt = `You are a PeakRDL-renode expert and C# Renode peripheral developer.

Your job: given SystemRDL source and a PeakRDL compilation error, diagnose and fix the RDL.

## PeakRDL-renode specifics
- PeakRDL-renode generates C# for Renode (https://renode.io) peripheral emulation
- Common errors:
  * "Overlapping field" — two fields occupy the same bit range
  * "Invalid access type" — use sw/hw properties correctly
  * "Missing reset" — every field needs a reset value
  * "Unresolved reference" — check property names and IDs
  * "Invalid address" — addresses must be properly aligned

## Renode C# peripheral structure
\`\`\`csharp
using Antmicro.Renode.Core.Structure.Registers;
using Antmicro.Renode.Peripherals.Bus;

public class MyPeripheral : BasicDoubleWordPeripheral, IKnownSize
{
    public MyPeripheral(Machine machine) : base(machine) { DefineRegisters(); }
    public long Size => 0x1000;

    private void DefineRegisters()
    {
        Registers.CTRL.Define(this)
            .WithFlag(0, name: "EN")
            .WithValueField(1, 2, name: "MODE");
    }

    private enum Registers : long { CTRL = 0x0, STATUS = 0x4 }
}
\`\`\`

## Steps
1. Read the PeakRDL error carefully
2. Identify the RDL line/construct causing the error
3. Call patch_rdl with the fixed RDL and a clear description of the fix
4. If PeakRDL is unavailable or unfixable after 3 attempts, call generate_csharp_fallback`;

  return createReactAgent({
    llm,
    tools: [patchRdlTool, generateCsharpFallbackTool],
    messageModifier: systemPrompt,
  });
}

// ─── Main export ───────────────────────────────────────────────────────────

/**
 * Run PeakRDL-renode, self-heal on errors, generate README of fixes.
 * Returns { csharp: string, readme: string[], patchedRdl: string }
 */
export async function runCsharpPipeline(rdl, outputDir, maxIterations = 10) {
  log.divider?.('Stage 4 — RDL → C# via PeakRDL-renode');

  fs.mkdirSync(outputDir, { recursive: true });

  const rdlFile = path.join(outputDir, 'registers.rdl');
  fs.writeFileSync(rdlFile, rdl, 'utf8');
  log.perceive(`RDL written to: ${rdlFile}`);

  const fixes = [];
  let currentRdl = rdl;
  let csharp = null;
  let attempt = 0;
  const maxAttempts = 3;

  // ── Agent loop: try → observe error → reason → patch → retry ────────────
  while (attempt < maxAttempts) {
    attempt++;
    log.reason(`PeakRDL attempt ${attempt}/${maxAttempts}`);

    const peakResult = runPeakRdl(rdlFile, outputDir);

    if (peakResult.success) {
      csharp = peakResult.output;
      log.success(`PeakRDL succeeded on attempt ${attempt}`);
      break;
    }

    log.observe(`PeakRDL error (attempt ${attempt}): ${peakResult.error.slice(0, 300)}`);

    if (attempt >= maxAttempts) {
      log.warn('Max PeakRDL attempts reached — invoking fallback C# generation');
      break;
    }

    // ── Invoke self-healing agent ──────────────────────────────────────────
    const agentMsg = `
PeakRDL-renode failed with this error:

--- ERROR ---
${peakResult.error}
--- END ERROR ---

RDL source that caused the error:

--- RDL ---
${currentRdl}
--- END RDL ---

Diagnose the error and call patch_rdl with a corrected RDL. Describe the fix clearly.
    `.trim();

    const agent = buildCsharpAgent();
    const result = await agent.invoke(
      { messages: [new HumanMessage(agentMsg)] },
      { recursionLimit: maxIterations }
    );

    // Extract patched RDL or fallback C# from tool messages
    let patched = null;
    for (const msg of result.messages) {
      if (msg.constructor.name !== 'ToolMessage') continue;

      if (msg.name === 'patch_rdl') {
        try {
          const p = JSON.parse(msg.content);
          if (p.patched && p.rdl) {
            patched = p.rdl;
            fixes.push(`Attempt ${attempt}: ${p.fix}`);
            log.observe(`Fix applied: ${p.fix}`);
          }
        } catch { /* ignore */ }
      }

      if (msg.name === 'generate_csharp_fallback') {
        try {
          const p = JSON.parse(msg.content);
          if (p.generated && p.csharp) {
            csharp = p.csharp;
            fixes.push(`Attempt ${attempt}: PeakRDL unfixable — generated C# directly. ${p.notes}`);
            log.warn(`Fallback C# generated: ${p.notes}`);
          }
        } catch { /* ignore */ }
      }
    }

    if (csharp) break; // fallback was triggered

    if (patched) {
      currentRdl = patched;
      fs.writeFileSync(rdlFile, currentRdl, 'utf8');
      log.act(`Patched RDL written for retry`);
    } else {
      log.warn('Agent did not produce a patch — trying direct C# fallback');
      fixes.push(`Attempt ${attempt}: Agent produced no patch — using deterministic fallback`);
      break;
    }
  }

  // ── Last resort: deterministic C# generation from RDL text ────────────
  if (!csharp) {
    log.warn('All PeakRDL attempts failed — generating C# deterministically from RDL structure');
    csharp = await generateCsharpDirectly(currentRdl);
    fixes.push('Final fallback: C# generated directly from RDL parsing (PeakRDL unavailable or all attempts failed)');
  }

  // ── README content ────────────────────────────────────────────────────
  const readme = buildReadme(fixes, rdl, currentRdl);

  // Write final outputs
  const csPath = path.join(outputDir, 'RegisterPeripheral.cs');
  fs.writeFileSync(csPath, csharp, 'utf8');

  const patchedRdlPath = path.join(outputDir, 'registers_final.rdl');
  if (currentRdl !== rdl) {
    fs.writeFileSync(patchedRdlPath, currentRdl, 'utf8');
    log.info(`Patched RDL saved: ${patchedRdlPath}`);
  }

  log.success(`C# written: ${csPath}`);
  return { csharp, readme: fixes, patchedRdl: currentRdl, csPath };
}

// ─── Direct C# generation fallback ─────────────────────────────────────────

async function generateCsharpDirectly(rdl) {
  // Use a separate LLM call (not agent) to generate C# from the (possibly patched) RDL
  const llm = new ChatOpenAI({
    model: process.env.VLLM_MODEL || 'Qwen/Qwen3-6B',
    temperature: 0,
    maxTokens: 8192,
    configuration: {
      baseURL: process.env.VLLM_BASE_URL || 'http://localhost:8000/v1',
      apiKey: process.env.VLLM_API_KEY || 'EMPTY',
    },
  });

  const prompt = `Generate valid Renode C# peripheral code from this SystemRDL source.
Output ONLY the C# code — no markdown, no explanation.

${rdl}`;

  const response = await llm.invoke([new HumanMessage(prompt)]);
  return response.content.replace(/```[a-z]*/g, '').replace(/```/g, '').trim();
}

// ─── README builder ────────────────────────────────────────────────────────

function buildReadme(fixes, originalRdl, finalRdl) {
  const hasChanges = fixes.length > 0;
  const changed = originalRdl !== finalRdl;

  return `# PeakRDL-renode Conversion — README

Generated: ${new Date().toISOString()}

## Summary

${hasChanges
  ? `The RDL → C# conversion required **${fixes.length} fix(es)** to complete successfully.`
  : 'The RDL → C# conversion completed without errors.'}

## Fixes Applied

${fixes.length > 0
  ? fixes.map((f, i) => `### Fix ${i + 1}\n${f}`).join('\n\n')
  : '_No fixes were required._'}

## Files Generated

| File | Description |
|------|-------------|
| \`RegisterPeripheral.cs\` | Renode C# peripheral (main output) |
| \`registers.rdl\` | Original SystemRDL input |
${changed ? `| \`registers_final.rdl\` | Patched RDL after fixes |\n` : ''}| \`master.json\` | Parsed register map (JSON) |
| \`registers.toml\` | TOML intermediate |

## Usage

### Load peripheral in Renode
\`\`\`
(monitor) machine LoadPlatformDescription @platforms/your_platform.repl
\`\`\`

Add to your \`.repl\`:
\`\`\`
myPeripheral: RegisterPeripheral @ sysbus 0x40000000
\`\`\`

### Verify with PeakRDL
\`\`\`bash
pip install peakrdl-renode
peakrdl renode registers_final.rdl -o .
\`\`\`
`;
}
