// src/index.js
// CLI entry point for the Register Agent Pipeline
// Usage: node src/index.js --file doc.pdf --pages 134:450 --file regs.xlsx --sheets "Registers,Bitfields"

import 'dotenv/config';
import { program } from 'commander';
import path from 'path';
import { runPipeline } from './pipeline/orchestrator.js';
import { logger } from './utils/logger.js';

program
  .name('register-agent')
  .description(
    'LangChain Deep Agent Pipeline: Documents (PDF/DOCX/XLSX) → JSON → TOML → RDL → C# (PeakRDL-renode)'
  )
  .version('1.0.0');

program
  .option(
    '-f, --file <path>',
    'Input file path. Repeat for multiple files.',
    collect,
    []
  )
  .option(
    '-p, --pages <from:to>',
    'Page range for the last --file (PDF/DOC/DOCX). E.g. --pages 134:450',
    collect,
    []
  )
  .option(
    '-s, --sheets <names>',
    'Comma-separated sheet names for the last --file (XLSX/XLSM). E.g. --sheets "Registers,Bitfields"',
    collect,
    []
  )
  .option(
    '-o, --output <dir>',
    'Output directory (default: ./output)',
    './output'
  )
  .option(
    '--rdl-prompt <file>',
    'Path to custom RDL system prompt .md file (default: config/rdl_system_prompt.md)'
  )
  .option(
    '--max-iterations <n>',
    'Max agent loop iterations per stage (default: 10)',
    '10'
  )
  .option(
    '--demo',
    'Run with built-in demo data (no real files needed — for testing)'
  );

program.parse();

const opts = program.opts();

// ─── Argument parsing ──────────────────────────────────────────────────────

function collect(val, prev) {
  return prev.concat([val]);
}

/**
 * Pair up --file, --pages, --sheets flags in order.
 * Each --file can be followed by at most one --pages and one --sheets.
 */
function buildFileHints(files, pages, sheets) {
  return files.map((filePath, i) => {
    const hint = { filePath: path.resolve(filePath) };

    if (pages[i]) {
      const [from, to] = pages[i].split(':');
      hint.pageFrom = from;
      hint.pageTo   = to;
    }

    if (sheets[i]) {
      hint.sheets = sheets[i].split(',').map(s => s.trim());
    }

    return hint;
  });
}

// ─── Demo mode ────────────────────────────────────────────────────────────

function buildDemoHints() {
  // Creates a small synthetic text "document" in memory for smoke-testing.
  // Writes it to a temp file so the parser can read it.
  import('fs-extra').then(async ({ default: fs }) => {
    const tmpDir = '/tmp/register-agent-demo';
    await fs.ensureDir(tmpDir);

    // Write a fake register document as a plain text file that we'll treat as a DOCX
    // (mammoth will fail on .txt, so we write a minimal DOCX-like structure)
    // Instead: write a JSON file that the agent can read directly
    logger.warn('Demo mode: using built-in synthetic register data');
  });

  // Return an empty hint list — the agent will use synthetic data from its training
  return [];
}

// ─── Main ─────────────────────────────────────────────────────────────────

async function main() {
  if (!process.env.ANTHROPIC_API_KEY) {
    logger.error('ANTHROPIC_API_KEY is not set. Copy .env.example → .env and add your key.');
    process.exit(1);
  }

  let fileHints;

  if (opts.demo) {
    logger.info('Running in demo mode — no input files required');
    // Use a simple inline demo document
    fileHints = await buildDemoFileHints();
  } else if (opts.file.length === 0) {
    logger.error('No input files specified. Use --file <path> or --demo for a test run.');
    program.help();
    process.exit(1);
  } else {
    fileHints = buildFileHints(opts.file, opts.pages, opts.sheets);
    logger.info(`Input files: ${fileHints.length}`);
    fileHints.forEach((h, i) => {
      let extra = '';
      if (h.pageFrom || h.pageTo) extra += ` pages ${h.pageFrom}–${h.pageTo}`;
      if (h.sheets)               extra += ` sheets: ${h.sheets.join(', ')}`;
      logger.info(`  [${i + 1}] ${h.filePath}${extra}`);
    });
  }

  try {
    await runPipeline({
      files:              fileHints,
      outputDir:          opts.output,
      rdlSystemPromptFile: opts.rdlPrompt,
      maxIterations:      parseInt(opts.maxIterations),
    });
  } catch (err) {
    logger.error(`Pipeline failed: ${err.message}`);
    if (process.env.DEBUG) console.error(err.stack);
    process.exit(1);
  }
}

async function buildDemoFileHints() {
  // Write a small synthetic register document that the pipeline can parse
  const { default: fs } = await import('fs-extra');
  const tmpDir  = '/tmp/register-agent-demo';
  const docPath = `${tmpDir}/demo_registers.txt`;
  await fs.ensureDir(tmpDir);

  await fs.writeFile(docPath, `
REGISTER MAP — Demo Peripheral v1.0

Register: CTRL (Control Register)
Address:  0x00
Access:   RW
Reset:    0x00000000

Bit Fields:
  [0]    EN      RW   0   Enable the peripheral
  [1]    RST     WO   0   Software reset (write 1 to reset)
  [3:2]  MODE    RW   0   Operating mode: 00=idle 01=tx 10=rx 11=loopback
  [7:4]  DIV     RW   0   Clock divider

---

Register: STATUS (Status Register)
Address:  0x04
Access:   RO
Reset:    0x00000000

Bit Fields:
  [0]    BUSY    RO   0   Peripheral busy
  [1]    ERR     RO   0   Error flag
  [2]    OVF     RO   0   Overflow flag

---

Register: DATA (Data Register)
Address:  0x08
Access:   RW
Reset:    0x00000000

Bit Fields:
  [31:0] VALUE   RW   0   Data payload

---

Register: IRQ_EN (Interrupt Enable)
Address:  0x0C
Access:   RW
Reset:    0x00000000

Bit Fields:
  [0]    TX_IE   RW   0   TX complete interrupt enable
  [1]    RX_IE   RW   0   RX complete interrupt enable
  [2]    ERR_IE  RW   0   Error interrupt enable
  `.trim(), 'utf8');

  // Treat as docx-like (mammoth will handle .txt gracefully or we route manually)
  // Use a custom route: rename to .doc so our parser handles it
  const docxPath = docPath.replace('.txt', '.docx');

  // Since we can't make a real DOCX, we'll inject the content directly.
  // Create a workaround: write JSON that the orchestrator pre-loads
  const jsonPath = `${tmpDir}/demo_registers_preparsed.json`;
  await fs.writeJSON(jsonPath, {
    demo: true,
    content: await fs.readFile(docPath, 'utf8'),
    fileName: 'demo_registers.docx',
  }, { spaces: 2 });

  logger.info(`Demo document written to: ${docPath}`);

  // Return a hint pointing at the text file — the parser will treat it as raw text
  return [{ filePath: docPath, _rawText: true }];
}

main();
