// src/utils/logger.js
import chalk from 'chalk';

const LOOP_STAGES = ['PERCEIVE', 'REASON', 'PLAN', 'ACT', 'OBSERVE'];

export class Logger {
  constructor(prefix = '') {
    this.prefix = prefix;
    this.iteration = 0;
  }

  _ts() {
    return chalk.gray(new Date().toISOString().split('T')[1].slice(0, 12));
  }

  info(msg) {
    console.log(`${this._ts()} ${chalk.blue('[INFO]')} ${this.prefix ? chalk.cyan(`[${this.prefix}]`) : ''} ${msg}`);
  }

  success(msg) {
    console.log(`${this._ts()} ${chalk.green('[OK]')}  ${this.prefix ? chalk.cyan(`[${this.prefix}]`) : ''} ${msg}`);
  }

  warn(msg) {
    console.log(`${this._ts()} ${chalk.yellow('[WARN]')} ${this.prefix ? chalk.cyan(`[${this.prefix}]`) : ''} ${msg}`);
  }

  error(msg) {
    console.log(`${this._ts()} ${chalk.red('[ERR]')}  ${this.prefix ? chalk.cyan(`[${this.prefix}]`) : ''} ${msg}`);
  }

  agentLoop(stage, msg) {
    const stageStr = chalk.magenta(`[LOOP:${stage}]`);
    console.log(`${this._ts()} ${stageStr} ${this.prefix ? chalk.cyan(`[${this.prefix}]`) : ''} ${msg}`);
  }

  perceive(msg)  { this.agentLoop('PERCEIVE', msg); }
  reason(msg)    { this.agentLoop('REASON',   msg); }
  plan(msg)      { this.agentLoop('PLAN',     msg); }
  act(msg)       { this.agentLoop('ACT',      msg); }
  observe(msg)   { this.agentLoop('OBSERVE',  msg); }

  divider(label) {
    const line = '─'.repeat(60);
    console.log(`\n${chalk.dim(line)}`);
    console.log(chalk.bold(`  ${label}`));
    console.log(`${chalk.dim(line)}\n`);
  }
}

export const logger = new Logger();
