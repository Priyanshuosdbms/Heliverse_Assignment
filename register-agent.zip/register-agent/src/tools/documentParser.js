// src/tools/documentParser.js
// Handles PDF, DOC, DOCX, XLSX, XLSM extraction with page/sheet hints.
// Also handles raw .txt files (demo mode).

import fs from 'fs';
import path from 'path';
import pdfParse from 'pdf-parse';
import mammoth from 'mammoth';
import * as XLSX from 'xlsx';
import { Logger } from '../utils/logger.js';

const log = new Logger('PARSER');

/**
 * @typedef {Object} FileHint
 * @property {string} filePath         - absolute path to the file
 * @property {string} [pageFrom]       - for PDF/DOC/DOCX: start page (1-based)
 * @property {string} [pageTo]         - for PDF/DOC/DOCX: end page (1-based)
 * @property {string[]} [sheets]       - for XLSX/XLSM: sheet names to read
 * @property {boolean} [_rawText]      - internal: treat file as plain text (demo mode)
 */

export async function parseDocument(hint) {
  const { filePath, pageFrom, pageTo, sheets, _rawText } = hint;
  if (!fs.existsSync(filePath)) throw new Error(`File not found: ${filePath}`);

  const ext      = path.extname(filePath).toLowerCase().slice(1);
  const fileName = path.basename(filePath);
  log.perceive(`Reading ${fileName} [type: ${_rawText ? 'text' : ext}]`);

  if (_rawText || ext === 'txt') {
    const content = fs.readFileSync(filePath, 'utf8');
    log.observe(`Plain text: ${content.length.toLocaleString()} chars`);
    return { fileName, type: 'txt', content };
  }

  switch (ext) {
    case 'pdf':   return parsePDF(filePath, fileName, pageFrom, pageTo);
    case 'doc':
    case 'docx':  return parseWord(filePath, fileName, pageFrom, pageTo);
    case 'xlsx':
    case 'xlsm':  return parseExcel(filePath, fileName, sheets);
    default:      throw new Error(`Unsupported file type: .${ext}`);
  }
}

async function parsePDF(filePath, fileName, pageFrom, pageTo) {
  const data = await pdfParse(fs.readFileSync(filePath));
  let text = data.text;
  if (pageFrom || pageTo) {
    const from = parseInt(pageFrom) || 1;
    const to   = parseInt(pageTo)   || data.numpages;
    log.plan(`PDF page filter: ${from}–${to} of ${data.numpages}`);
    const pages = text.split(/\f/);
    text = pages.slice(from - 1, to).join('\n');
    log.observe(`Extracted ${Math.min(to, pages.length) - (from - 1)} page(s)`);
  }
  return { fileName, type: 'pdf', content: text.trim() };
}

async function parseWord(filePath, fileName, pageFrom, pageTo) {
  let text = (await mammoth.extractRawText({ path: filePath })).value;
  if (pageFrom || pageTo) {
    log.warn('Page ranges for DOCX are approximated by paragraph count');
    const paras = text.split(/\n{2,}/);
    const from  = ((parseInt(pageFrom) || 1) - 1) * 4;
    const to    = (parseInt(pageTo) || Math.ceil(paras.length / 4)) * 4;
    text = paras.slice(from, to).join('\n\n');
  }
  return { fileName, type: 'docx', content: text.trim() };
}

async function parseExcel(filePath, fileName, requestedSheets) {
  const workbook  = XLSX.readFile(filePath);
  const allSheets = workbook.SheetNames;
  let targets     = allSheets;
  if (requestedSheets && requestedSheets.length > 0) {
    targets = requestedSheets.filter(s => {
      if (allSheets.includes(s)) return true;
      log.warn(`Sheet "${s}" not found. Available: ${allSheets.join(', ')}`);
      return false;
    });
    if (targets.length === 0) { log.warn('No valid sheets — reading all'); targets = allSheets; }
  }
  log.plan(`Reading sheets: ${targets.join(', ')}`);
  const parts = targets.map(s => `## Sheet: ${s}\n${XLSX.utils.sheet_to_csv(workbook.Sheets[s])}`);
  return { fileName, type: 'xlsx', content: parts.join('\n\n').trim() };
}

export async function parseAllDocuments(hints) {
  const results = [];
  for (const hint of hints) {
    try {
      const parsed = await parseDocument(hint);
      results.push(parsed);
      log.success(`Parsed: ${parsed.fileName} (${parsed.content.length.toLocaleString()} chars)`);
    } catch (err) {
      log.error(`Failed to parse ${hint.filePath}: ${err.message}`);
      throw err;
    }
  }
  return results;
}
